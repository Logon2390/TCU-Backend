import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { Subject } from 'rxjs';

@Injectable()
export class MailService {

    private transporter = nodemailer.createTransport({
        service: 'gmail', // or 'hotmail', 'outlook', 'yahoo', etc.
        auth: {
            user: '',
            pass: '',
        },
    });

    async sendResetPassword(to: string, token: string) {

        const resetLink = `http://localhost:5173/user/reset?token=${token}`;

        await this.transporter.sendMail({
            from: '"Centro Civico Por la Paz Pococi" <ccorreo>',
            to,
            Subject: 'Recuperacion de contraseña',

            html: `<p> Haz click para restablecer tu contraseña:</p> 
            <a href="${resetLink}">Restablecer contraseña</a>
            <p>Este enlace expirará en 15 minutos.</p>`

        })
    }

}